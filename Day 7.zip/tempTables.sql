-- http://msdn.microsoft.com/en-us/library/ms186986.aspx
/*
Temporary Tables are quite similar to Permanent Tables in database; 
Permanent Tables are created in a specific database and persist until the database exists. 
Whilst Temporary Tables are created in the tempdb and are automatically deleted 
when they are no longer in use. 

Types of Temporary Tables
    -Local Temporary Tables
    -Global Temporary Tables
----------------------------------------------------

Local Temporary Tables:
------------------------
Local temporary tables are the tables stored in tempdb. 
Local temporary tables are temporary tables that are available only to the session that 
created them. 
These tables are automatically destroyed at the termination of the procedure or session. 
They are specified with the prefix #, for example #table_name.

characteristics of local Temporary Tables:
    1-It starts with single hash value "#" as the prefix of the table name.
    2-A Local Temporary Table is only for the session (connection) in which it was created.
    3-Each Local Temporary Table has a random value at the end of the table name.
    4-Automatically dropped when the existing connection is closed, 
	or the user can explicitly drop it with the following command "drop table #Android".
    5-If the Temporary Table is created in a Stored Procedure then it is automatically 
	dropped on the completion of the Stored Procedure execution.
    6-You can create a Local Temporary Table with the same name but in a different 
	connection, and it is stored with the same name along with various random values.
*/
create table #myTbl
(
		ID int identity Primary Key,
		Name nvarchar(20)
)
-- its lifetime for current session only
--exists in tempdb=>Temporary Tables
insert into #myTbl(Name)
values ('Karim')
,('Mostafa')
,('Ibrahim') 
go
select * from #myTbl
go

--try to open a new query and repeat the previous query
--Invalid object name '#temp'
							-------------------


/*Global Temporary Tables:  
--------------------------
Global temporary tables are also stored in tempdb. 
Available to all sessions and all users. 
They are dropped automatically when the last session using the temporary table has completed. 
They are specified with the prefix ##, for example ##table_name.

characteristics of Global Temporary Tables:
    1-It starts with  "##" as the prefix of the table name and its name is always unique. 
	There is no random number appended to the name.
    2-Global Temporary Tables are visible to all connections of SQL Server.
    3-Global Temporary Tables are only destroyed when the last connection referencing the table is closed 
	(in which we have created the Global Temporary Table).
    4-You can access the Global Temporary Tables from all connections of SQL Server until 
	the referencing connection is open.
*/

create table ##MySharedTemp
(
		ID int identity Primary Key,
		Name nvarchar(20)
)
--exists in tempdb=>Temporary Tables
--dbo.MySharedTemp

insert into ##MySharedTemp(Name)
values ('Karim')
,('Mostafa')
,('Ibrahim') 
go	
			
select * from ##MySharedTemp
--open a new Query and write the following query

select * from dbo.##MySharedTemp 
--data will be retrieved	
--will be removed when
--			1. Drop it manually
--			2. Restart the server	
--			3.Last session conected to it closes			
				------------------------------
Drop table ##MySharedTemp