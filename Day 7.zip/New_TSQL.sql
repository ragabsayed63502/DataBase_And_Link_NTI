--T-SQL Categoris:
--DML
--DML is abbreviation of Data Manipulation Language. It is used to retrieve, store, modify, delete, insert and update data in database.
--Examples: Delete, UPDATE, INSERT statements

-- DQL 
-- SQL Select Statments

--DDL
--DDL is abbreviation of Data Definition Language. It is used to create and modify the structure of database objects in database.
--Examples: CREATE, ALTER, DROP statements

--DCL
--DCL is abbreviation of Data Control Language. It is used to create roles, permissions, and referential integrity as well it is used to control access to database by securing it.
--Examples: GRANT, Deny, REVOKE statements

--TCL
--TCL is abbreviation of Transactional Control Language. It is used to manage different transactions occurring within a database.
--Examples: COMMIT, ROLLBACK statements

--=========================================================

--Sys info & system tables structure
-------------------------------------------------------------


----------------------------------
--ROWNUMBER()
-- ROW_NUMBER is a temporary value calculated when the query is run.
-- https://docs.microsoft.com/en-us/sql/t-sql/functions/row-number-transact-sql?view=sql-server-ver15

 
SELECT ROW_NUMBER() OVER(ORDER BY FirstName DESC) AS 'No',   
    FirstName, LastName
FROM Sales.vSalesPerson 
----------------------------------
--TOP
-- Limits the rows returned in a query result set to a specified number of rows or percentage of rows
-- https://docs.microsoft.com/en-us/sql/t-sql/queries/top-transact-sql?view=sql-server-ver15

-- Select the first 10 random employees.  
SELECT TOP(10) Title, HireDate  
FROM HumanResources.Employee
GO  
-- Select the first 10 employees hired most recently.  
SELECT TOP 10 Title, HireDate  
FROM HumanResources.Employee  
ORDER BY HireDate DESC;  
GO
  

----------------------------------
-- Using TOP with a variable
DECLARE @p AS INT = 12;  
SELECT TOP(@p)Title, HireDate, VacationHours  
FROM HumanResources.Employee  
ORDER BY VacationHours DESC;  
GO  
------------------------
--Using TOP to limit the number of rows deleted, inserted or Updated
select * from Purchasing.PurchaseOrderDetail  
DELETE TOP (20)   
FROM Purchasing.PurchaseOrderDetail  
WHERE DueDate < '20020701';  
GO  
----------------------------------------------
-- Offset, fetch
-- The OFFSET and FETCH clauses are the options of the ORDER BY clause. They allow you to limit the number of rows to be returned by a query.
-- https://docs.microsoft.com/en-us/sql/t-sql/queries/select-order-by-clause-transact-sql?view=sql-server-ver15
-- https://www.sqlservertutorial.net/sql-server-basics/sql-server-offset-fetch/

--Examples
-- Return all rows sorted by the column DepartmentID.  
SELECT DepartmentID, Name, GroupName  
FROM HumanResources.Department  
ORDER BY DepartmentID;  
  
-- Skip the first 5 rows from the sorted result set and return all remaining rows.  
SELECT DepartmentID, Name, GroupName  
FROM HumanResources.Department  
ORDER BY DepartmentID OFFSET 7 ROWS;  
  
-- Skip 5 rows and return only the first 10 rows from the sorted result set.  
SELECT DepartmentID, Name, GroupName  
FROM HumanResources.Department  
ORDER BY DepartmentID   
OFFSET 5 ROWS  FETCH NEXT 10 ROWS ONLY; 

-- Specifying variables for OFFSET and FETCH values
DECLARE @RowsToSkip TINYINT = 2
      , @FetchRows TINYINT = 8;
	    
SELECT DepartmentID, Name, GroupName  
FROM HumanResources.Department  
ORDER BY DepartmentID ASC   
    OFFSET @RowsToSkip ROWS   
    FETCH NEXT @FetchRows ROWS ONLY; 

-----------------------------------------------------------
--Correlated SubQueries
/* https://docs.microsoft.com/en-us/sql/relational-databases/performance/subqueries?view=sql-server-ver15
   https://www.mssqltips.com/sqlservertip/6037/sql-server-uncorrelated-and-correlated-subquery/
Many queries can be evaluated by executing the subquery once and substituting the resulting value or values into the WHERE clause of the outer query. In queries that include a correlated subquery (also known as a repeating subquery), the subquery depends on the outer query for its values. This means that the subquery is executed repeatedly, once for each row that might be selected by the outer query.
*/
--Example

USE AdventureWorks;
GO
-- Sub Query
SELECT DISTINCT c.LastName, c.FirstName, e.ContactID
FROM Person.Contact AS c JOIN HumanResources.Employee AS e
ON e.ContactID = c.ContactID
WHERE 5000.00 IN
    (SELECT Max(Bonus) FROM Sales.SalesPerson) ;
GO
---------------------





-----------------------------------------------------------
--CTE (Common Table Expression)
/* -- https://docs.microsoft.com/en-us/sql/t-sql/queries/with-common-table-expression-transact-sql?view=sql-server-ver15
Specifies a temporary named result set, known as a common table expression (CTE). 
A common table expression (CTE) can be thought of as a temporary result set that is defined within the execution scope of a single SELECT, INSERT, UPDATE, DELETE, or CREATE VIEW statement. A CTE is similar to a derived table in that it is not stored as an object and lasts only for the duration of the query. Unlike a derived table, a CTE can be self-referencing and can be referenced multiple times in the same query.
A CTE can be used to: 
Create a recursive query. For more information, see Recursive Queries Using Common Table Expressions.
Substitute for a view when the general use of a view is not required; that is, you do not have to store the definition in metadata.

Enable grouping by a column that is derived from a scalar subselect, or a function that is either not deterministic or has external access.
Reference the resulting table multiple times in the same statement.

Using a CTE offers the advantages of improved readability and ease in maintenance of complex queries. The query can be divided into separate, simple, logical building blocks. These simple blocks can then be used to build more complex, interim CTEs until the final result set is generated. 
*/
USE AdventureWorks;
GO
-- Define the CTE expression name and column list.
WITH Sales_CTE  
AS  
(  
    SELECT SalesPersonID as SalesPersonID, COUNT(*) as NumberOfOrders  
    FROM Sales.SalesOrderHeader  
    WHERE SalesPersonID IS NOT NULL  
    GROUP BY SalesPersonID  
)  
SELECT SalesPersonID, AVG(NumberOfOrders) AS "Average Sales"  
FROM Sales_CTE
GROUP BY SalesPersonID;
-----
WITH Sales_CTE (SalesPersonID, OrderID, SalesYear) 
AS
-- Define the CTE query.
(
    SELECT SalesPersonID, SalesOrderID, YEAR(OrderDate)
    FROM Sales.SalesOrderHeader
    WHERE SalesPersonID IS NOT NULL
)
-- Define the outer query referencing the CTE name.
SELECT SalesPersonID, COUNT(OrderID) AS TotalSales, SalesYear
FROM Sales_CTE
GROUP BY SalesYear, SalesPersonID
ORDER BY SalesPersonID, SalesYear;
GO
-----------------------------------------------------------
/*Self-Study*/
--Compare CTE to temp Tables
-----------------------------------------------------------
-- Pivot, unpivot

-- https://docs.microsoft.com/en-us/sql/t-sql/queries/from-using-pivot-and-unpivot?view=sql-server-ver15
-- https://www.sqlservertutorial.net/sql-server-basics/sql-server-pivot/
-- Ranking
-- https://docs.microsoft.com/en-us/sql/t-sql/functions/rank-transact-sql?view=sql-server-ver15
-----------------------------------------------------------
--ROll,Cube 
--Rank
--Merge
-----------------------------------------------------------
--Bulk Insert
--Imports a data file into a database table or view in a user-specified format in SQL Server 2008 R2. Use this statement to efficiently transfer data between SQL Server and heterogeneous data sources.
--http://msdn.microsoft.com/en-us/library/ms188365.aspx
